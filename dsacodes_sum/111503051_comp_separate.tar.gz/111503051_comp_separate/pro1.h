int proone(int num, int *ans);
