#include <stdio.h>
#include <errno.h>
#include "graph.h"
int main(int argc, char *argv[]) {
	graph *g;
	int i;
	if(argc < 2)  {
		errno = EINVAL;
		perror("usage: ./program filename");
		return errno;
	}
	g = readfromfile(argv[1]);
	if(g)
		print(g);
	for(i = 0; i < getn(g) ; i++) {
		//levelwise(g, i);
		//depthwise(g, i);
		prims(g, i);
	}
	return 0;
}
