#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
typedef struct info {
	int info;
	char name[16];
	double score;
}info;
int main(int argc, char *argv[]) {
	int file, i = 1;
	if(argc < 2) {
	errno = EINVAL;
	perror("bad arguments");
	exit(errno);
	}
	file = open(argv[1], O_WRONLY | O_CREAT, S_IRUSR | S_IWUSR);
	if(file == -1) {
		perror("cannot open/create the file");
		exit(errno);
	}
	info *ar;
	if((ar = (info *)malloc(sizeof(info))) == NULL) {
		perror("memory not available");
		exit(errno);
	}
	/*take input from user untill he presses ^D*/
	while(-1 != scanf("%d%s%lf", &(ar[i-1].info), ar[i-1].name, &(ar[i-1].score))) {
		ar = (info *)realloc(ar, (i + 1) * sizeof(info));
		i++;
	}
	i--;
	/*write all data to the file*/
	write(file, &i, sizeof(int));
	write(file, ar, i * sizeof(info));
	close(file);
	return 0;
}
