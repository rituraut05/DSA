#include <stdio.h>
#include "pro1.h"
int main() {
	int num, ans = 0;
	printf("Enter a number\n");
	scanf("%d", &num);
	proone(num, &ans);
	printf("No of steps required for the procedure is %d\n", ans);
	return 0;
}
