#include <stdio.h>
#include <stdlib.h>
void dupli(double *ar, int *n) {
	double *dupremove = (double *)malloc(*n * sizeof(double));
	int lendup = 0;
	int i, j;
	for(i = 0; i < *n; i++) {
		for(j = 0; j < lendup; j++)
			if(dupremove[j] == ar[i])
				break;
		if(j == lendup) {
			dupremove[lendup++] = ar[i];
		}
	}
	for(j = 0; j < lendup; j++) {
		ar[j] = dupremove[j];
	}
	*n = lendup - 1;
	free(dupremove);
}
int main() {
	double ar[100];
	int i = 0, j = 0;
	while(scanf("%lf", &ar[i++]) != -1);
	dupli(ar, &i);
	for(j = 0; j < i; j++)
		printf("%lf ", *(ar + j));
	putchar('\n');
	return 0;
}
