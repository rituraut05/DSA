#include "pro2.h"
int proone(int num, int *ans) {
	if(num == 0)
		return 0;
	(*ans)++;
	protwo(num - 1, ans);
	return 0;
}
