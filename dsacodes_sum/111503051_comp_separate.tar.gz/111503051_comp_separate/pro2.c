#include "pro1.h"
int protwo(int num, int *ans) {
	if(num == 0)
		return 0;
	(*ans)++;
	proone(num / 2, ans);
	return 0;
}
