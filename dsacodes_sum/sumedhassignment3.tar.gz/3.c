#include <stdio.h>
#include <sys/types.h> /* for open() */
#include <sys/stat.h> /* for open() */
#include <fcntl.h> /* for open() */
#include <stdlib.h> /* for exit() */
#include <unistd.h> /* for read() */
#include <errno.h>
#include <ctype.h>
int main(int argc, char *argv[]) {
	if(argc < 2) {
		errno = EINVAL;
		perror("bad arguments");
		return errno;
	}
	int rfd, flag = 0;
	char c = 1;
	rfd = open(argv[1], O_RDONLY);
	if(rfd == -1) {
		perror("can't open file");
		exit(errno);
	}
	while((flag = read(rfd, &c, 1))) {
		if((! isprint(c)) && (! isspace(c))) {
			printf("Binary file\n");
			break;
		}
	}
	if(! flag)
		printf("text file\n");
	close(rfd);
	return 0;
}
