#include <stdio.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
typedef struct info {
	int id;
	char name[16];
	double score;
}info;
int main(int argc, char * argv[]) {
	int file, total = 0, i;
	info *ar;
	if(argc < 3) {
		errno = EINVAL;
		perror("bad arguments");
		exit(errno);
	}
	double req = atof(argv[2]);
	if((file = open(argv[1], O_RDONLY)) == -1) {
		perror("cannot open the file");
		exit(errno);
	}
	read(file, &total, sizeof(int));
	if((ar = (info *)malloc(total * sizeof(info))) == NULL) {
		perror("memory couldn't be allocated");
		exit(errno);
	}
	read(file, ar, total * sizeof(info));
	for(i = 0; i < total; i++) {
		if(req == ar[i].score)
			printf("%d %s %lf\n", ar[i].id, ar[i].name, ar[i].score);
	}
	close(file);
	return 0;
}
