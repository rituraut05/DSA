#include <stdio.h>
#include "stack.h"
/* Compile and run as follows:
 * >cc -c try.c
 * >cc stack.o try.o -o try
 * >./try
 * 
 * No need to write the stack implementation (stack.c) again! 
 */

int main() {
	stack s;
	int i;
	init(&s);
	for(i = 0;i < 10;i++)
		push(&s, i);
	for(i = 0;i < 10;i++)
		printf("%d\n", pop(&s));
	return 0;
	
}
