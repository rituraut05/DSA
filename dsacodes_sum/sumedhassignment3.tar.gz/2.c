#include <stdio.h>
#include <sys/types.h> /* for open() */
#include <sys/stat.h> /* for open() */
#include <fcntl.h> /* for open() */
#include <stdlib.h> /* for exit() */
#include <unistd.h> /* for read() */
#include <errno.h>
typedef struct data {
	int age;
	char name[16];
}data;
int main(int argc, char *argv[]) {
	if(argc < 2) {
		errno = EINVAL;
		perror("bad arguments");
		return errno;
	}
	int rfd, quantity = 0, flag = 0, num=0;
	char c = 1;
	rfd = open(argv[1], O_RDONLY);
	if(rfd == -1) {
		perror("can't open file");
		exit(errno);
	}
	//section 1
	flag = read(rfd, &quantity, sizeof(int));
	while(quantity != 0 && (flag = read(rfd, &num, sizeof(int)))) {
		printf("%d\n", num);
		quantity--;
	}
	//section 2
	flag = read(rfd, &quantity, sizeof(int));
	data varone;
	while(quantity != 0 && (flag = read(rfd, &varone, sizeof(data)))) {
		printf("%d %s\n", varone.age, varone.name);
		quantity--;
	}
	//section 3
	flag = read(rfd, &quantity, sizeof(int));
	while(quantity != 0 && (flag = read(rfd, &c, sizeof(char)))) {
		if(c == '\0') {
			printf("\n");
			quantity--;
		}
		else
			putchar(c);
	}
		
	return 0;
}
		
