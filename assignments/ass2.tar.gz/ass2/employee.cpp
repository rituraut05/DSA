#include<iostream>
using namespace std;
class employee{
	private:
		char name[20];
		char department[40];
		float salary;
	public:
		void getdata(){
			cout<<"Enter your name,department, salary\n";
			cin>>name>>department>>salary;
		}
		void showdata(){
			cout<<"NAME :"<<name<<endl<<"Department :"<<department<<endl<<"salary :"<<salary<<endl;
		}
};
int main(){
	employee obj;
	obj.getdata();
	obj.showdata();
	return 0;
}

