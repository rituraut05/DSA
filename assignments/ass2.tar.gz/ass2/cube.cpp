#include<iostream>
using namespace std;
class cube{
	private:
		float length, vol ,area;
	public:
		void getdata(){
			cout<<"Enter the length of th side of the cube\n";
			cin>>length;
		}
		void cal_volume(){
			vol = length * length * length;
			cout<<"The volume of the cube is "<<vol<<endl;
		}
		void cal_surface_area(){
			area = 6 * length * length;
			cout<<"The surface area of the cube is "<<area<<endl;
		}
};
int main(){
	cube obj;
	obj.getdata();
	obj.cal_volume();
	obj.cal_surface_area();
	return 0;
}

