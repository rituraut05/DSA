#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "cstack.h"
#include "token.h"
int precedence(char op) {
	if(op == '%')
		return 3;
	if(op == '*' || op == '/')
		return 2;
	if(op == '+' || op == '-')
		return 1;
	return 0;
}
char ctop(cstack *cs) {
	char x = cpop(cs);
	cpush(cs, x);
	return x;
}
char *intopost(char *infix) {
	char *result = (char *)malloc(128);
	cstack cs;
	token *t;
	char temp[16];
	int reset = 1, a, b;
	char x;

	strcpy(result, "");
	cinit(&cs);
	while(1) {
		t = getnext (infix, &reset);
		if(t->type == OPERAND) {
			sprintf(temp, "%d", t->number);
			strcat(result, temp);
			strcat(result, " ");			
		}
		else if (t->type == OPERATOR) {
			if(!cempty(&cs)) {
				x = ctop(&cs);	
				a = precedence(x);	
				b = precedence(t->op);	
				while(a >= b) {
					x = cpop(&cs);	
					temp[0] = x; temp[1] = ' ';
					temp[2] = '\0';
					strcat(result, temp);
					if(!cempty(&cs)) {
						x = ctop(&cs);	
						a = precedence(x);
					}
					else
						break;
				}
			}
			cpush(&cs, t->op);
		} else if (t->type == END) {
			while(!cempty(&cs)) {
				x = cpop(&cs);
				temp[0] = x; temp[1] = ' ';
				temp[2] = '\0';
				strcat(result, temp);
			}
			return result;
		} else
			return NULL;
	}
}
