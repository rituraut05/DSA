#include<iostream>
#define pi 3.1427
using namespace std;
class circle{
	private:
		 float area, circum, radius;
	public:
		void get_data(){
			cout<<"Enter the radius of the circle\n";
			cin>>radius;
		}
		void cal_area(){
			area = pi * radius * radius;
			cout<<"The area of the circle is "<<area<<endl;		
		}
		void cal_circum(){
			circum = 2 * pi * radius;
			cout<<"The circumference of the circle is "<<circum<<endl;		
		}

};

int main(){
	circle obj;
	obj.get_data();
	obj.cal_area();
	obj.cal_circum();
	return 0;

}
