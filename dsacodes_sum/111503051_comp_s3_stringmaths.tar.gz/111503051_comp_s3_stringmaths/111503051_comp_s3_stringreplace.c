#include <stdio.h>
#include <string.h>
#include <stdlib.h>
int stringreplace(char *text, char *orig, char  *new) {
	int count = 0, i = 0, j;
	int lentext = strlen(text);
	int lenorig = strlen(orig);
	char *p;
	int ctr = 0;
	char *newstr = (char *)malloc(lentext);
	for(; i < lentext; i++)
		newstr[i] = text[i];
	for(i = 0; i < lentext; i++) {
		p = new;
		for(j = 0; j < lenorig && i + j < lentext; j++)
			if(newstr[i+j] != orig[j])
				break;
		if(j == lenorig) {
			i = i + j - 1;
			count++;
			while(*p != '\0') {
				text[ctr++] = *p;
				p++;
			}
		}
		else
			text[ctr++] = newstr[i];
	}
	text[ctr] = '\0';	
	free(newstr);
	return count;
}
int main() {
    char text[128], orig[128], new[128]; // don't assume size of 128 in the function stringreplace, it is not available in the function!
    int count;
    while(scanf("%s%s%s", text, orig, new) != -1) {
       count = stringreplace(text, orig, new);
       printf("%d %s\n", count, text);
    }

}
