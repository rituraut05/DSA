#include<iostream>
using namespace std;
class rectangle{
	private:
		 float area, perim, length, breadth;
	public:
		void get_data(){
			cout<<"Enter the length and breadth of the rectangle\n";
			cin>>length>>breadth;
		}
		void cal_area(){
			area = length * breadth;
			cout<<"The area of the rectangle is "<<area<<endl;		
		}
		void cal_perim(){
			perim = 2*(length + breadth);
			cout<<"The perimeter of the rectangle is "<<perim<<endl;		
		}

};

int main(){
	rectangle obj;
	obj.get_data();
	obj.cal_area();
	obj.cal_perim();
	return 0;
};

