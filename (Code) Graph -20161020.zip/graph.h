
typedef struct graph {
	int n;
	int **a;
}graph;

int getn(graph *g);
void levelwise(graph *g, int);
void ginit(graph *g, int n);
graph *readfromfile(char *filename); 
void print(graph *g);


