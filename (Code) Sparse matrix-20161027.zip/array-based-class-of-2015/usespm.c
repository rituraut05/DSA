#include <stdio.h>
#include "spm.h"
int main() {
	spm a, b, *c;
	int row, col, val;
	initspm(&a, 3, 3);
	initspm(&b, 3, 3);
	/* code to read spm a */
	while(scanf("%d%d%d", &row, &col, &val) != EOF)
		appendspm(&a, row, col, val);
	printspm(&a);
	/* code to read spm b */
	while(scanf("%d%d%d", &row, &col, &val) != EOF)
		appendspm(&b, row, col, val);
	printspm(&b);
	c = addspm(&a, &b);
	printspm(c);
	c = multspm(&a, &b);
	printspm(c);
	return 0;	
}
