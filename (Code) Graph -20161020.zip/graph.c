#include <stdio.h>
#include <limits.h>
#include <stdlib.h>
#include <errno.h>
#include "graph.h"
#include "queue.h"
int getn(graph *g) {
	return g->n;
}
void ginit(graph *g, int n) {
	int i, j;
	g->n = n;
	g->a = (int **)malloc(sizeof(int *) * n);
	for(i = 0; i < n; i++) {
		g->a[i] = (int *)malloc(sizeof(int) * n);
		for(j = 0; j < n; j++)
			g->a[i][j] = 0;
	}
}
void print(graph *g) {
	int i, j;
	printf("Graph: \n");
	for(i = 0; i < g->n; i++) {
		for(j = 0; j < g->n; j++) 
			printf("%3d", g->a[i][j]);
		printf("\n");
	}
	printf("\n");
}
graph *readfromfile(char *filename) {
	graph *g = (graph *)malloc(sizeof(graph));
	FILE *fp = fopen(filename, "r");
	int n = 0, i, j;
	if(fp == NULL) {
		perror("can't open file:");
		return  NULL;
	}
	fscanf(fp, "%d", &n);
	ginit(g, n);
	for(i = 0; i < n; i++)
		for(j = 0; j < n; j++)
			fscanf(fp, "%d", &(g->a[i][j]));
	return g;
}
void levelwise(graph *g, int r) {
	int v, *visited, j;
	queue q;
	qinit(&q);

	visited = (int *)malloc(sizeof(int) * g->n);
	for(j = 0; j < g->n; j++)
		visited[j] = 0;
	printf("[ ");
	enqueue(&q, r);
	visited[r] = 1;
	while(!qempty(&q)) {
		v = dequeue(&q);
		for(j = 0; j < g->n; j++)
			if(g->a[v][j] != 0 && visited[j] == 0) {
				enqueue(&q, j);
				visited[j] = 1;
			}
		printf("%d ", v);
	}
	printf("] \n");
}
void dft(graph *g, int v, int *visited) {
/* do a DFT of graph g, starting in vertex v */
	//visited = (int *)malloc(sizeof(int) * g->n);
	int j;
	printf("%d ", v);
	visited[v] = 1;
	for(j = 0; j < g->n; j++)
		if(g->a[v][j] && !visited[j])
			dft(g, j, visited);	
}
void depthwise(graph *g, int v) {
	int *visited = (int *)malloc(sizeof(int) * g->n);
	int j;
	for(j = 0; j < g->n; j++)
		visited[j] = 0;
	printf("DFT: [ ");
	dft(g, v, visited);
	printf("]\n");
}
typedef struct edge {
	int from, to;
}edge;
edge *prims(graph *g, int v) {
	edge *result = (edge *)malloc(sizeof(edge)*  (g->n - 1));
	int *visited = (int *)malloc(sizeof(int) * g->n);
	int ei = 0, vi = 0, k, minweight, i, j;

	for(j = 0; j < g->n; j++)
		visited[j] = 0;

	int *vertices = (int *)malloc(sizeof(int) * g->n );

	vertices[vi++] = v;
	visited[v] = 1;

	edge minedge;

	for(k = 0; k < g->n - 1; k++) {
		minedge.from = -1;
		minedge.to = -1;	
		minweight = INT_MAX;
		for(i = 0; i < vi; i++) {
			for(j = 0; j < g->n; j++)
				if(g->a[vertices[i]][j] != 0 && !visited[j]) {
					if(g->a[i][j] < minweight) {
						minedge.from = vertices[i];
						minedge.to = j;
						minweight = g->a[i][j];
					}
				}
		}
		/*select edge <c, d> s.t.
			c belonggs to V, and d doesnt belong to V
			and <c , d> has min weight */
		if(minedge.from != -1) {
			vertices[vi++] = minedge.to;
			visited[minedge.to] = 1;
			result[ei++] = minedge;
		} else {
			break;
		}
		//result = result + <c, d>
	}	
	printf("prims: Root %d \n", v);
	for(k = 0; k < ei; k++)
		printf("%d->%d, ", result[k].from, result[k].to); 
	printf("\n");
}
