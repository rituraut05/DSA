#include<iostream>
using namespace std;
class student{
	private:
		char name[20];
		int rollno;
		float cgpa;
	public:
		void getdata(){
			cout<<"Enter your name, roll number, cgpa\n";
			cin>>name>>rollno>>cgpa;
		}
		void showdata(){
			cout<<"NAME :"<<name<<endl<<"ROLL NUMBER :"<<rollno<<endl<<"CGPA :"<<cgpa<<endl;
		}
};
int main(){
	student obj;
	obj.getdata();
	obj.showdata();
	return 0;
}

