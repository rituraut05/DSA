#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <ctype.h>
int main(int argc, char *argv[]) {
	if(argc < 2) {
		errno = EINVAL;
		perror("bad arguments");
		return errno;
	}
	int fd, flag = 0;
	char c = 1;
	fd = open(argv[1], O_RDONLY);
	if(fd == -1) {
		perror("can't open file");
		exit(errno);
	}
	while((flag = read(fd, &c, 1))) {
		if((! isprint(c)) && (! isspace(c))) {
			printf("Binary file\n");
			break;
		}
	}
	if(! flag)
		printf("Text file\n");
	close(fd);
	return 0;
}
