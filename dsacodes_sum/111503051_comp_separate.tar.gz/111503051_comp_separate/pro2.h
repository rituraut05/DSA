int protwo(int num, int *ans);
