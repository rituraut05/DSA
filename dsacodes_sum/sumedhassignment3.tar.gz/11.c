#include <stdio.h>
#include <sys/types.h> /* for open() */
#include <sys/stat.h> /* for open() */
#include <fcntl.h> /* for open() */
#include <stdlib.h>
#include <unistd.h> /* for read() */
#include <errno.h>
typedef struct info {
	int info;
	char name[16];
	double score;
}info;
int main(int argc, char *argv[]) {
	int file, i = 1;
	char c = 'y';
	if(argc < 2) {
	errno=EINVAL;
	perror("bad arguments");
	exit(errno);
	}
	file = open(argv[1], O_WRONLY | O_CREAT, S_IRUSR | S_IWUSR);
	if(file == -1) {
		perror("cannot open/create the file");
		exit(errno);
	}
	info *ar;
	ar = (info *)malloc(0);
	while(c == 'y') {
		printf("Enter the Elements of the structure\n");
		ar = (info *)realloc(ar, i * sizeof(info));
		scanf("%d%s%lf", &(ar[i-1].info), ar[i-1].name, &(ar[i-1].score));
		printf("Do you want to continue?(y/n)?\n");
		getchar();
		c = getchar();
		i++;
	}
	i--;
	write(file, &i, sizeof(int));
	write(file, ar, i * sizeof(info));
	return 0;
}
