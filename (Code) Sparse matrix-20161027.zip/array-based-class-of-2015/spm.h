typedef struct entry {
	int r, c, v;
}entry;
typedef struct spm {
	entry a[16];
	int nr, nc, nentry;
}spm;

spm *addspm(spm *a, spm *b);
spm *multspm(spm *a, spm *b);
void initspm(spm *a, int, int);
int getelem(spm *a, int r, int c);
void appendspm(spm *a, int r, int c, int v);
void printspm(spm *a);
