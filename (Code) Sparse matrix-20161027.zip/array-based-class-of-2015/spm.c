#include <stdlib.h>
#include <stdio.h>
#include "spm.h"
int compare(spm *a, spm *b, int i, int j) {
	if(a->a[i].r < b->a[j].r)
		return -1;
	if(a->a[i].r > b->a[j].r)
		return 1;
	if(a->a[i].c < b->a[j].c)
		return -1;
	if(a->a[i].c > b->a[j].c)
		return 1;
	return 0;
	
}
spm *addspm(spm *a, spm *b){
	if(a->nr != b->nr || a->nc != b->nc)
		return NULL;
	spm *c = (spm *)malloc(sizeof(spm));
	initspm(c, a->nr, a->nc);
	int i, j, res;
	i = 0;
	j = 0;
	while(i < a->nentry && j < b->nentry) {
		res = compare(a, b, i, j); 
		if(res == -1)  {
			appendspm(c, a->a[i].r, a->a[i].c, a->a[i].v);
			i++;
		}
		else if(res == 1) {
			appendspm(c, b->a[j].r, b->a[j].c, b->a[j].v);
			j++;
		}
		else  {
			if(b->a[j].v + a->a[i].v)
				appendspm(c, b->a[j].r, b->a[j].c, b->a[j].v + a->a[i].v);
			i++; j++;
		}
	}
	if(i == a->nentry)
		while(j < b->nentry) {
			appendspm(c, b->a[j].r, b->a[j].c, b->a[j].v);
			j++;
		}
	else
		while(i < a->nentry) {
			appendspm(c, a->a[i].r, a->a[i].c, a->a[i].v);
			i++;
		}
		
	return c;
}
spm *multspm(spm *a, spm *b){
	int i, j, k, sum, x, y;
	if(a->nc != b->nr)
		return NULL;
	spm *c = (spm *)malloc(sizeof(spm));
	initspm(c, a->nr, b->nc);
	for(i = 0; i < a->nr; i++) 
		for(j = 0; j < b->nc; j++) {
			sum = 0;
			for(k = 0; k < a->nc; k++) {
				x = getelem(a, i, k);
				y = getelem(b, k, j);
				sum += x * y;
			}
			if(sum)
				appendspm(c, i, j, sum);
		}
	return c;
	
}
void initspm(spm *a, int nr, int nc){
	a->nr = nr;
	a->nc = nc;
	a->nentry = 0;
}
int getelem(spm *a, int r, int c){
	int i = 0;
	while(i < a->nentry) {
		if(a->a[i].r == r && a->a[i].c == c)
			return a->a[i].v;
		i++;
	}
	return 0;
}
void appendspm(spm *a, int r, int c, int v){
	a->a[a->nentry].r = r;
	a->a[a->nentry].c = c;
	a->a[a->nentry].v = v;
	a->nentry++;
}
void printspm2(spm *a) {
	int i;
	printf("--------\n");
	printf("%d %d %d\n", a->nr, a->nc, a->nentry);
	printf("--------\n");
	for(i = 0; i < a->nentry; i++)
		printf("%d %d %d\n", a->a[i].r, a->a[i].c, a->a[i].v);
	printf("--------\n\n");
}
void printspm(spm *a) {
	int k = 0, i, j;
	printf("-------------\n");
	for(i = 0; i < a->nr; i++) {
		for(j = 0; j < a->nc; j++) {
			if(a->a[k].r == i && a->a[k].c == j)
				printf("%d ", a->a[k++].v);
			else
				printf("%d ", 0);
		}
		printf("\n");
	}
	printf("-------------\n");
}
