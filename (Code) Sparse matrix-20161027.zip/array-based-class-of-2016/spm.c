#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>
typedef struct entry {
	int r, c, v;
}entry;

typedef struct spm {
	char name[16];
	entry a[128];
	int nc, nr, n;
}spm;
void spm_init(spm *s, int nr, int nc, char *name) {
	s->nc  = nc;
	s->nr = nr;
	s->n = 0;
	strcpy(s->name, name);
}
void addentry(spm *s, int r, int c, int v) {
	int j = s->n - 1;
	while(j >= 0) {
		if((s->a[j].r > r) || ((s->a[j].r == r) && (s->a[j].c > c)))
			s->a[j + 1] = s->a[j];
		else
			break;
		j--;
	}
	s->a[j + 1].c = c;	
	s->a[j + 1].r = r;	
	s->a[j + 1].v = v;	
	s->n++;
}
int search(int r, int c, spm *mat) {
	int l, h, m;
	l = 0;
	h = mat->n - 1;
	while(l <= h) {
		m = (l + h) / 2;
		if(mat->a[m].r == r && mat->a[m].c == c)
			return m;
		if((mat->a[m].r < r) || ((mat->a[m].r == r) && (mat->a[m].c < c)))
			l = m + 1;
		else
			h = m - 1;
	}
	return -1;
}
spm *spm_add(spm *p, spm *q) {
	if(p->nr != q->nr || p->nc != q->nc)
		return NULL;
	spm *c = (spm *)malloc(sizeof(spm));
	spm_init(c, p->nr, p->nc, "RESULT");
	int i, x;

	for(i = 0; i < p->n; i++) { // p->a[i] is current entry 
	//for every entry in p
		x = search(p->a[i].r, p->a[i].c, q);
		if((x != -1) && (p->a[i].v + q->a[x].v))
			addentry(c, p->a[i].r, p->a[i].c, p->a[i].v + q->a[x].v);
		else
			addentry(c, p->a[i].r, p->a[i].c, p->a[i].v);
	}
	for(i = 0; i < q->n; i++) { // q->a[i] is current entry  
		x = search(q->a[i].r, q->a[i].c, p);
		if(x == -1)
			addentry(c, q->a[i].r, q->a[i].c, q->a[i].v);
	}
	return c;
}
void spm_print(spm *p) {
	int i;
	printf("SPM: %s\n", p->name);
	
	for(i = 0; i < p->n; i++)
		printf("(%d, %d), %d\n", p->a[i].r, p->a[i].c, p->a[i].v);
}
int main() {
	spm a, b, *res;
	int nr, nc;
	int r, c, v;
	char name[16];
	scanf("%d%d%s", &nr, &nc, name);
	spm_init(&a, nr, nc, name);
	
	while(scanf("%d%d%d", &r, &c, &v) != -1)
		addentry(&a, r, c, v);
	
	spm_print(&a);

	scanf("%d%d%s", &nr, &nc, name);
	spm_init(&b, nr, nc, name);
	
	while(scanf("%d%d%d", &r, &c, &v) != -1)
		addentry(&b, r, c, v);
	
	spm_print(&b);

	res = spm_add(&a, &b);
	if(res)
		spm_print(res);
	return 0;
}
