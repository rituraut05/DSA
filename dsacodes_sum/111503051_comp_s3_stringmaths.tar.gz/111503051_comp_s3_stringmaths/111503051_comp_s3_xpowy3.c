#include <stdio.h>
#include <stdlib.h>
double power(int x, int y) {
        int sign = 0;
        long term, answer;
        if(x == 0 && y == 0) {
		printf("0^0 is undefined\n");
		exit(1);
	}
        else if(x == 0)
		return 0.0;
        else {
                if(y == 0)
                        return 1.0;
                else {
                        if(y < 0) {
                                sign = 1;
                                y = -y;
                        }
                        term = x;
                        answer = 1;
                        while(y) {
                                if(y % 3 == 1)
                                        answer = answer * term;
				else if(y % 3 == 2)
					answer = answer * term * term;
                                y /= 3;
                                term = term * term * term;
                        }
                        if(sign)
                                return (1.0) / answer;
                        else
                                return (double)answer;
                }
        }
}
int main() {
        int x, y;
        scanf("%d%d", &x, &y);
        printf("%lf\n", power(x,y));
	return 0;
}

