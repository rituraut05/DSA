#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
typedef struct data {
	int age;
	char name[16];
}data;
int main(int argc, char *argv[]) {
	if(argc < 2) {
		errno = EINVAL;
		perror("bad arguments");
		return errno;
	}
	int fd, quantity = 0, flag = 0, num = 0;
	char c = 1;
	fd = open(argv[1], O_RDONLY);
	if(fd == -1) {
		perror("can't open file");
		exit(errno);
	}
	/*part 1: reading integers*/
	flag = read(fd, &quantity, sizeof(int));
	while(quantity != 0 && (flag = read(fd, &num, sizeof(int)))) {
		printf("%d\n", num);
		quantity--;
	}
	/*part 2: reading structures*/
	flag = read(fd, &quantity, sizeof(int));
	data varone;
	while(quantity != 0 && (flag = read(fd, &varone, sizeof(data)))) {
		printf("%d %s\n", varone.age, varone.name);
		quantity--;
	}
	/*part 3: reading strings*/
	flag = read(fd, &quantity, sizeof(int));
	while(quantity != 0 && (flag = read(fd, &c, sizeof(char)))) {
		if(c == '\0') {
			printf("\n");
			quantity--;
		}
		else
			putchar(c);
	}
	close(fd);
	return 0;
}
		
