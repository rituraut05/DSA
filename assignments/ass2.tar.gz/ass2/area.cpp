#include<iostream>
#define pi 3.1427
using namespace std;
class cal_area{
	private:
		 float area,length, breadth, radius, base, height;
	public:
		void get_data(){
		}
		void cal_area_circle(){
			cout<<"Enter the radius of the circle\n";
			cin>>radius;
			area = pi * radius * radius;
			cout<<"The area of the circle is "<<area<<endl;		
		}
		void cal_area_rect(){
			cout<<"Enter the length and breadth of the rectangle\n";
			cin>>length>>breadth;
			area = length * breadth;
			cout<<"The area of the rectangle is "<<area<<endl;		
		}
		void cal_area_tri(){
			cout<<"Enter the base and height of the triangle\n";
			cin>>base>>height;
			area = 0.5 * height * base;
			cout<<"The area of the triangle is "<<area<<endl;		

	}
};

int main(){
	cal_area obj;
	obj.cal_area_rect();
	obj.cal_area_tri();
	obj.cal_area_circle();
	return 0;

}
