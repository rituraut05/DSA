compile and run the postfix program like this:
	cc -c stack.c
	cc -c postfix3.c
	cc stack.o postfix.o -o postfix 
	./postfix
compile and  run the try program like this:
	cc -c try.c 
	cc try.o stack.o -o try
	./try
